v1.0.2: fix NPE when painting before decompression finishes (file==null guard + loading screen); 30fps repaint + debug row cache from v1.0.1
